# Arcade Study — Orbital Edition (Android)

This project wraps the supplied `ArcadeStudy_Orbital_Edition.html` in a fullscreen Android WebView. The game assets are bundled locally, so the app does not need an internet connection.

## Build an APK with Android Studio
1. Install Android Studio (including Android SDK Platform 35).
2. Open this folder as an existing Android project.
3. Let Gradle sync finish.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Build automatically on GitHub
1. Create a new GitHub repository and upload the contents of this folder.
2. Open **Actions → Build Android APK → Run workflow** (or push to `main`).
3. Download the `ArcadeStudy-Orbital-APK` artifact from the completed workflow run.

## Sharing with reviewers
The debug APK is suitable for direct testing on Android devices. Android may ask the recipient to allow installation from the app/file source. For a public Play Store release, create a separately signed release build with a private signing key; do not share that key.

Package ID: `com.arcadestudy.orbital`
Version: `1.0`
Minimum Android: 6.0 (API 23)
